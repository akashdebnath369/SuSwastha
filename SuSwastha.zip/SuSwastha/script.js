const servicesData = [
  {
    title: "Heart Disease Prediction",
    desc: "Evaluate cardiovascular risk with cholesterol, ECG, and lifestyle markers.",
  },
  {
    title: "Diabetes Check",
    desc: "Assess glucose trends, BMI, insulin, and pedigree factors to classify risk.",
  },
  {
    title: "Blood Pressure Check",
    desc: "Log systolic/diastolic values plus habits to pinpoint hypertension stages.",
  },
  {
    title: "BMI & Body Composition",
    desc: "Monitor weight trends with contextual coaching and habit reminders.",
  },
  {
    title: "Cholesterol Profile",
    desc: "Track HDL, LDL, triglycerides and receive actionable nutrition tips.",
  },
  {
    title: "Liver Function",
    desc: "Spot liver stress early through ILPD markers and probability insights.",
  },
];

const timelineFeed = [
  { test: "Kidney Function", region: "Pune, IN", movement: "+42%", status: "Spike" },
  { test: "Heart Disease", region: "Doha, QA", movement: "+18%", status: "Trending" },
  { test: "Diabetes Panel", region: "Bengaluru, IN", movement: "-9%", status: "Stabilizing" },
  { test: "Thyroid Function", region: "Singapore", movement: "+22%", status: "Rising" },
];

const healthTips = [
  "Hydrate before every fasting test for accurate readings.",
  "Pair every report with 10 minutes of reflection to plan next steps.",
  "Consistency beats intensity—track metrics weekly instead of sporadically.",
  "Sleep quality changes most blood biomarker trends. Target 7+ hours.",
  "Share your dashboard with a clinician to co-create lifestyle nudges.",
];

document.addEventListener("DOMContentLoaded", () => {
  const yearTarget = document.getElementById("year");
  if (yearTarget) {
    yearTarget.textContent = new Date().getFullYear();
  }

  // Smooth scroll for internal links
  document.querySelectorAll('a[href^="#"]').forEach((anchor) => {
    anchor.addEventListener("click", (event) => {
      const targetId = anchor.getAttribute("href");
      const targetElement = document.querySelector(targetId);
      if (targetElement) {
        event.preventDefault();
        targetElement.scrollIntoView({ behavior: "smooth" });
      }
    });
  });

  const simpleForms = document.querySelectorAll("[data-simple-submit]");
  simpleForms.forEach((form) => {
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      alert("Thanks! Our care team will respond shortly.");
      form.reset();
    });
  });

  const servicesGrid = document.getElementById("services-grid");
  if (servicesGrid) {
    servicesGrid.innerHTML = servicesData
      .map(
        (service) => `
        <article class="service-card">
          <h3>${service.title}</h3>
          <p>${service.desc}</p>
        </article>`
      )
      .join("");
  }

  const timelineTarget = document.getElementById("timeline-feed");
  if (timelineTarget) {
    timelineTarget.innerHTML = timelineFeed
      .map(
        (event) => `
        <div class="timeline-item">
          <div class="timeline-meta">
            <h4>${event.test}</h4>
            <p class="muted">${event.region}</p>
          </div>
          <span class="pill">${event.status} · ${event.movement}</span>
        </div>`
      )
      .join("");
  }

  const tipTarget = document.getElementById("health-tip");
  const shuffleTipBtn = document.getElementById("shuffle-tip");
  if (tipTarget && shuffleTipBtn) {
    let currentIndex = 0;
    const setTip = (index) => {
      tipTarget.textContent = healthTips[index];
    };
    const rotateTip = () => {
      currentIndex = (currentIndex + 1) % healthTips.length;
      setTip(currentIndex);
    };
    shuffleTipBtn.addEventListener("click", rotateTip);
    setTip(currentIndex);
    setInterval(rotateTip, 8000);
  }

  const reportForm = document.getElementById("report-generator");
  const reportOutput = document.querySelector("[data-report-output]");
  if (reportForm && reportOutput) {
    reportForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const formData = new FormData(reportForm);
      const name = formData.get("name") || "Member";
      const selectedTest = formData.get("test") || "General Wellness";
      const date = formData.get("date") || new Date().toISOString().slice(0, 10);
      const notes = formData.get("notes") || "No additional notes provided.";

      reportOutput.innerHTML = `
        <p><strong>Recipient:</strong> ${name}</p>
        <p><strong>Test:</strong> ${selectedTest}</p>
        <p><strong>Date:</strong> ${date}</p>
        <p><strong>Highlights:</strong> Metrics are within the expected range. Continue monitoring weekly.</p>
        <p><strong>Clinician notes:</strong> ${notes}</p>
      `;
    });
  }

  const downloadBtn = document.querySelector("[data-download-pdf]");
  if (downloadBtn) {
    downloadBtn.addEventListener("click", () => {
      window.print();
    });
  }

  const animateSections = document.querySelectorAll("[data-animate]");
  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          observer.unobserve(entry.target);
        }
      });
    },
    { threshold: 0.15 }
  );

  animateSections.forEach((section) => observer.observe(section));

  const counters = document.querySelectorAll("[data-counter]");
  const counterObserver = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const target = entry.target;
          const finalValue = parseInt(target.dataset.target, 10);
          const hasPercent = target.textContent.includes("%");
          const duration = 1200;
          let start = 0;
          const increment = finalValue / (duration / 16);

          const tick = () => {
            start += increment;
            if (start >= finalValue) {
              target.textContent = `${target.dataset.target}${hasPercent ? "%" : ""}`;
            } else {
              target.textContent = `${Math.round(start)}${hasPercent ? "%" : ""}`;
              requestAnimationFrame(tick);
            }
          };

          requestAnimationFrame(tick);
          counterObserver.unobserve(target);
        }
      });
    },
    { threshold: 0.4 }
  );

  counters.forEach((counter) => counterObserver.observe(counter));

  const initThemeToggle = () => {
    const toggle = document.createElement("button");
    toggle.className = "theme-toggle";
    toggle.type = "button";

    const applyTheme = (theme) => {
      const isDark = theme === "dark";
      document.body.classList.toggle("dark", isDark);
      toggle.textContent = isDark ? "☀ Light Mode" : "🌙 Dark Mode";
      localStorage.setItem("suswastha-theme", theme);
    };

    const storedTheme = localStorage.getItem("suswastha-theme") || "light";
    applyTheme(storedTheme);

    toggle.addEventListener("click", () => {
      const nextTheme = document.body.classList.contains("dark") ? "light" : "dark";
      applyTheme(nextTheme);
    });

    document.body.append(toggle);
  };

  const initChatbot = () => {
    const fab = document.createElement("button");
    fab.className = "chatbot-fab";
    fab.type = "button";
    fab.textContent = "Ask SuSwastha";

    const panel = document.createElement("div");
    panel.className = "chatbot-panel";
    panel.innerHTML = `
      <div class="chatbot-header">
        <strong>SuSwastha Assistant</strong>
        <button type="button" aria-label="Close chatbot">&times;</button>
      </div>
      <div class="chatbot-messages"></div>
      <form class="chatbot-form">
        <input type="text" placeholder="Ask about tests, prep, lifestyle..." required />
        <button type="submit">Send</button>
      </form>
    `;

    const messages = panel.querySelector(".chatbot-messages");
    const closeBtn = panel.querySelector(".chatbot-header button");
    const chatbotForm = panel.querySelector(".chatbot-form");
    const input = panel.querySelector(".chatbot-form input");

    const responses = [
      "Remember to log readings at the same time daily for better trends.",
      "Hydration, balanced meals, and sleep are the easiest first wins.",
      "If your readings stay abnormal for a week, consider visiting a clinician.",
      "Pair your tests with our dashboard to see progress automatically.",
    ];

    const addMessage = (text, sender = "bot") => {
      const bubble = document.createElement("div");
      bubble.className = sender === "bot" ? "chatbot-message bot" : "chatbot-message";
      bubble.textContent = text;
      messages.append(bubble);
      messages.scrollTop = messages.scrollHeight;
    };

    addMessage("Hi! I'm here for quick health tips. How can I help?");

    fab.addEventListener("click", () => {
      panel.classList.toggle("open");
      if (panel.classList.contains("open")) {
        input.focus();
      }
    });

    closeBtn.addEventListener("click", () => {
      panel.classList.remove("open");
    });

    chatbotForm.addEventListener("submit", (event) => {
      event.preventDefault();
      const question = input.value.trim();
      if (!question) return;
      addMessage(question, "user");
      input.value = "";

      const lowered = question.toLowerCase();
      let reply =
        responses[Math.floor(Math.random() * responses.length)];

      if (lowered.includes("bp") || lowered.includes("blood pressure")) {
        reply = "Ensure you sit calmly for 5 minutes before taking a BP reading and track morning + evening values.";
      } else if (lowered.includes("diabetes") || lowered.includes("sugar") || lowered.includes("glucose")) {
        reply = "Pair fasting glucose with HbA1c every 3 months for a more accurate diabetes picture.";
      } else if (lowered.includes("cholesterol") || lowered.includes("lipid")) {
        reply = "Focus on fiber, omega-3 fats, and 150 minutes of cardio weekly to support cholesterol health.";
      }

      setTimeout(() => addMessage(reply), 400);
    });

    document.body.append(fab);
    document.body.append(panel);
  };

  initThemeToggle();
  initChatbot();
});
